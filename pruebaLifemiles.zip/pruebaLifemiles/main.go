package main

func main() {
	/*
		//Se crea la dependencia de para la lectura de configuracion (yaml y vault)
		config := configuration.GetInstance(configuration.NewDefaultSetting())

		//Dependencia de texto a binario
		textoBin := binario.NewBinarioTexto(config)
		//Dependencia de texto a morse
		textoMor := morse.NewTextoMorse(config)*/
}
