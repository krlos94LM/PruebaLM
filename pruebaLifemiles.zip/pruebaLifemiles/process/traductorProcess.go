package process

import (
	binario "pruebaLifemiles/traductor/binario"
	morse "pruebaLifemiles/traductor/morse"

	"git.lifemiles.net/lm-go-libraries/lifemiles-go/configuration"
)

type ServiceProcess interface {
	Traslate(textoATraducir string, formatoOrigen string, formatoDestino string) (string, error)
}

type traductorProcess struct {
	config       configuration.Config
	textoBinario binario.Service
	textoMorse   morse.Service
}

func NewTraductorProcess(
	config configuration.Config,
	textoBinario binario.Service,
	textoMorse morse.Service) *traductorProcess {
	return &traductorProcess{
		config:       config,
		textoBinario: textoBinario,
		textoMorse:   textoMorse,
	}
}

func (tp *traductorProcess) Traslate(textoATraducir string, formatoOrigen string, formatoDestino string) (string, error) {

	var textoTraducido string

	//verificamos el formato origen y destino

	if formatoOrigen == "TEXT" && formatoDestino == "BINARY" {
		textoTraducido, _ = tp.textoBinario.Convert(textoATraducir)
	} else if formatoOrigen == "TEXT" && formatoDestino == "MORSE" {
		textoTraducido, _ = tp.textoMorse.Convert(textoATraducir)
	}

	return textoTraducido, nil
}
