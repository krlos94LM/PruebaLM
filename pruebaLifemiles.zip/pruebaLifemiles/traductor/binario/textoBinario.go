package binario

import (
	"strings"

	"git.lifemiles.net/lm-go-libraries/lifemiles-go/configuration"
)

type binarioTexto struct {
	config configuration.Config
}

func NewBinarioTexto(
	config configuration.Config) *binarioTexto {
	return &binarioTexto{
		config: config,
	}
}

//Funcion para convertir un texto a binario
func (bt *binarioTexto) Convert(request interface{}) (interface{}, error) {

	//texto a traducir
	var textoATraducir string
	//texto traducido
	var textoTraducido = ""

	//Convertimos el tipo recibibo a string
	textoATraducir = request.(string)

	//Obtenemos las listas de textos y equivalente binario
	textoList := strings.Split(bt.config.GetString("conversion.texto"), ",")
	binarioList := strings.Split(bt.config.GetString("conversion.binario"), ",")

	for _, v := range textoATraducir {

		index, isContained := bt.contains(textoList, string(v))

		if isContained {
			textoTraducido = textoTraducido + binarioList[index]
		}

	}

	return textoTraducido, nil

}

func (bt *binarioTexto) contains(s []string, str string) (int, bool) {

	for i, v := range s {
		if v == str {
			return i, true
		}
	}

	return -1, false
}
