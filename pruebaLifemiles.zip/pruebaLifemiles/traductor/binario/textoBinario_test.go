package binario

import (
	"reflect"
	"testing"

	"git.lifemiles.net/lm-go-libraries/lifemiles-go/configuration"
)

func TestNewBinarioTexto(t *testing.T) {
	type args struct {
		config configuration.Config
	}

	//Inicializando las dependencias
	//create config
	config := configuration.GetInstance(configuration.NewSetting("../../", "application", "yaml", false))

	tests := []struct {
		name string
		args args
		want *binarioTexto
	}{
		{
			name: "Test NewBinarioTexto",
			args: args{
				config: config,
			},
			want: NewBinarioTexto(config),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewBinarioTexto(tt.args.config); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NewBinarioTexto() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_binarioTexto_Convert(t *testing.T) {

	type args struct {
		request interface{}
	}

	//Inicializando las dependencias
	//create config
	config := configuration.GetInstance(configuration.NewSetting("../../", "application", "yaml", false))

	testArgs := args{
		request: "ABC",
	}

	tests := []struct {
		name    string
		bt      *binarioTexto
		args    args
		want    interface{}
		wantErr bool
	}{
		{
			name: "Test Convert, Test Success",
			bt: &binarioTexto{
				config: config,
			},
			args:    testArgs,
			want:    "010000011100000101000010",
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.bt.Convert(tt.args.request)
			if (err != nil) != tt.wantErr {
				t.Errorf("binarioTexto.Convert() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("binarioTexto.Convert() = %v, want %v", got, tt.want)
			}
		})
	}
}
