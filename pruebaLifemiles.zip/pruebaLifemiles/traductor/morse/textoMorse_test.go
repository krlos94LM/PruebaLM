package morse

import (
	"reflect"
	"testing"

	"git.lifemiles.net/lm-go-libraries/lifemiles-go/configuration"
)

func TestNewTextoMorse(t *testing.T) {
	type args struct {
		config configuration.Config
	}

	//Inicializando las dependencias
	//create config
	config := configuration.GetInstance(configuration.NewSetting("../../", "application", "yaml", false))

	tests := []struct {
		name string
		args args
		want *textoMorse
	}{
		{
			name: "Test NewTextoMorse",
			args: args{
				config: config,
			},
			want: NewTextoMorse(config),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewTextoMorse(tt.args.config); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NewTextoMorse() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_textoMorse_Convert(t *testing.T) {
	type args struct {
		request interface{}
	}

	//Inicializando las dependencias
	//create config
	config := configuration.GetInstance(configuration.NewSetting("../../", "application", "yaml", false))

	testArgs := args{
		request: "ABC",
	}

	tests := []struct {
		name    string
		tm      *textoMorse
		args    args
		want    interface{}
		wantErr bool
	}{
		{
			name: "Test Convert, Test Success",
			tm: &textoMorse{
				config: config,
			},
			args:    testArgs,
			want:    ".--...-.-.",
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.tm.Convert(tt.args.request)
			if (err != nil) != tt.wantErr {
				t.Errorf("textoMorse.Convert() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("textoMorse.Convert() = %v, want %v", got, tt.want)
			}
		})
	}
}
