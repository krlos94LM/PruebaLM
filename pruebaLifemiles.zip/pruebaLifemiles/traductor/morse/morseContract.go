package morse

type Service interface {
	Convert(request interface{}) (interface{}, error)
}
