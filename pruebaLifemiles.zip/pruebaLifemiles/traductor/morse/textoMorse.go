package morse

import (
	"strings"

	"git.lifemiles.net/lm-go-libraries/lifemiles-go/configuration"
)

type textoMorse struct {
	config configuration.Config
}

func NewTextoMorse(
	config configuration.Config) *textoMorse {
	return &textoMorse{
		config: config,
	}
}

//Funcion para convertir un texto a binario
func (tm *textoMorse) Convert(request interface{}) (interface{}, error) {

	//texto a traducir
	var textoATraducir string
	//texto traducido
	var textoTraducido = ""

	//Convertimos el tipo recibibo a string
	textoATraducir = request.(string)

	//Obtenemos las listas de textos y equivalente morse
	textoList := strings.Split(tm.config.GetString("conversion.texto"), ",")
	morseList := strings.Split(tm.config.GetString("conversion.morse"), ",")

	for _, v := range textoATraducir {

		index, isContained := tm.contains(textoList, string(v))

		if isContained {
			textoTraducido = textoTraducido + morseList[index]
		}

	}

	return textoTraducido, nil

}

func (tm *textoMorse) contains(s []string, str string) (int, bool) {

	for i, v := range s {
		if v == str {
			return i, true
		}
	}

	return -1, false
}
